/** @type {import('next').NextConfig} */
const nextConfig = {devIndicators: false, reactStrictMode: false};

export default nextConfig;
